package com.example.furryfriendkeeper.dtos;

import com.example.furryfriendkeeper.entities.Petcategory;
import com.example.furryfriendkeeper.entities.ReviewDto;
import com.example.furryfriendkeeper.repositories.CategoriesRepository;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PetkeeperDTO {

    private Integer petkeeperId;
    private String name;
    private Set<String> Categories;
    private Integer reviewStars;


}
