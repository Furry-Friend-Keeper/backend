package com.example.furryfriendkeeper.services;

import com.example.furryfriendkeeper.dtos.PetkeeperDTO;
import com.example.furryfriendkeeper.entities.Petkeeper;
import com.example.furryfriendkeeper.repositories.CategoriesRepository;
import com.example.furryfriendkeeper.repositories.PetRepository;
import com.example.furryfriendkeeper.repositories.PetkeeperRepository;
import com.example.furryfriendkeeper.utils.ListMapper;
import jakarta.servlet.ServletOutputStream;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class PetkeeperService {

    @Autowired
    private final ModelMapper modelMapper;
    @Autowired
    private final ListMapper listMapper;
    @Autowired
    private final PetkeeperRepository petkeeperRepository;
    @Autowired
    private final PetRepository petRepository;
    @Autowired
    private final CategoriesRepository categoriesRepository;

    public List<PetkeeperDTO> getPetkeeperList(){
        List<Petkeeper> petkeeperList = petkeeperRepository.findAll();
        List<PetkeeperDTO> keepers = listMapper.mapList(petkeeperList, PetkeeperDTO.class, modelMapper);


        for(int i = 0; i < petkeeperList.size();i++){
            Set<String> categories = new LinkedHashSet<>();
            List<Integer> petcats = categoriesRepository.FindKeeperCategories(petkeeperList.get(i).getId());

            for(int a = 0; a < petcats.size(); a++){
                String name = petRepository.CateName(petcats.get(a));
                System.out.println(name);

                categories.add(name);
                System.out.println(categories);

                keepers.get(i).setCategories(categories);
                System.out.println(keepers.get(i).getCategories());

            }
            System.out.println(keepers.get(0).getCategories());
            System.out.println(keepers.get(1).getCategories());
            System.out.println(keepers.get(2).getCategories());
        }


        return keepers;
    }
}
