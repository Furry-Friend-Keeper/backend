package com.example.furryfriendkeeper.entities;

import lombok.Data;

import java.io.Serializable;

@Data
public class ReviewDto implements Serializable {
    private final Integer stars;
}
