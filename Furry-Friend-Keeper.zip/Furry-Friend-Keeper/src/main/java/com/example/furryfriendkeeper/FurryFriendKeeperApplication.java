package com.example.furryfriendkeeper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurryFriendKeeperApplication {

    public static void main(String[] args) {
        SpringApplication.run(FurryFriendKeeperApplication.class, args);
    }

}
