package com.example.furryfriendkeeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FurryFriendKeeperApplicationTests {

    @Test
    void contextLoads() {
    }

}
